import json
from urllib.request import Request
import httpx
import asyncio
from negocio.GeradorUUID import GeradorUUID

class RequisicoesCliente:
    
    gerador = GeradorUUID()

    def __init__(self, url_negocio):
        self.url_negocio = url_negocio

    async def seleciona_negocio(self):  # Requisição API ESCALONADOR
        url_escalonador = "http://localhost:8012/seleciona_negocio/"
        async with httpx.AsyncClient() as client:
            response = await client.get(url_escalonador,  timeout=30)
            # print('response ... ', response.json)
            return response.json()

    # Cria objeto Pessoa
    async def criaPessoa(self, nome): # Requisição para API de negócio
        url = f"{self.url_negocio}/criaPessoa/?nome={nome}"
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json={"nome": nome}, timeout=60.0)
            return response.json()
        
    # Adiciona itens no objeto Pessoa
    async def addItem(self, pessoa, itens): # Requisição para API de negócio
        url = f"{self.url_negocio}/addItem/"
        payload = {
            "pessoa": {
                "id": pessoa['id'],
                "nome": {"nome": pessoa['nome']['nome']},
                "lista": {
                    "id": pessoa['lista']['id'],
                    "listaItens": [],
                    "dataCriacao": pessoa['lista']['dataCriacao'],
                    "valorTotal": pessoa['lista']['valorTotal'],
                    "qtdTotalItens": pessoa['lista']['qtdTotalItens']
                }
            },
            "itens": itens
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, timeout=60.0)
            return response.json()

    # Realiza cálculo de qtd. total de itens e valor total
    # Retorna todo o objeto Pessoa com lista atualizada
    async def fazerCalculos(self, pessoa): # Requisição para API de negócio
        url = f"{self.url_negocio}/calculos/"
        payload = {
            "id": pessoa['id'],
            "nome": {"nome": pessoa['nome']['nome']},
            "lista": {
                "id": pessoa['lista']['id'],
                "listaItens": pessoa['lista']['listaItens'],
                "dataCriacao": pessoa['lista']['dataCriacao'],
                "valorTotal": pessoa['lista']['valorTotal'],
                "qtdTotalItens": pessoa['lista']['qtdTotalItens']
            }
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload)
            return response.json()
    
    # Gravação do objeto final
    async def grava(self, pessoa): # Requisição para API de negócio
        url = f"{self.url_negocio}/grava/"
        payload = {
            "id": pessoa['id'],
            "nome": {"nome": pessoa['nome']['nome']},
            "lista": {
                "id": pessoa['lista']['id'],
                "listaItens": pessoa['lista']['listaItens'],
                "dataCriacao": pessoa['lista']['dataCriacao'],
                "valorTotal": pessoa['lista']['valorTotal'],
                "qtdTotalItens": pessoa['lista']['qtdTotalItens']
            }
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, timeout=200.0)
            return response.json()

   