import json
import httpx
import asyncio
from negocio.GeradorUUID import GeradorUUID
from RequisicoesCliente import RequisicoesCliente

gerador = GeradorUUID()
servico = RequisicoesCliente(None)

print('\nVerificando conexão com o servidor de negócios...')
negocio = asyncio.run(servico.seleciona_negocio())
negocioOK = False

# print('negócio -- ', negocio)

# Verifica se a resposta contém as chaves 'ip' e 'porta', indicando uma conexão bem-sucedida
if isinstance(negocio, dict) and 'ip' in negocio and 'porta' in negocio:
    url_negocio = f"http://{negocio['ip']}:{negocio['porta']}"
    servico = RequisicoesCliente(url_negocio)
    negocioOK = True
    print('Conectado ao servidor ', url_negocio)
else:
    # Se a resposta não contém 'ip' e 'porta', trata-se de uma falha em todas as tentativas
    print("Não foi possível obter um serviço/negócio disponível.")

if negocioOK:
        
    # Boas-vindas
    print('\nSeja bem-vindo (a)! \nProcesso de utilização do sistema:\n- Cadastrar usuário único\n- Criar lista de compras\n- Visualizar lista de compras\n- Calcular valor total da lista\n\n')

    # Cria Pessoa e já vincular a uma lista vazia 
    # Requisição para a API de negócio
    nome = input("Digite seu nome: ")
    pessoa = asyncio.run(servico.criaPessoa(nome)) 

    continua = True
    if pessoa.get('Erro'):
        print(f'\nERRO: {pessoa["Erro"]}')
        continua = False
    else:
        print(pessoa['nome']['nome'], 'cadastrado (a) com sucesso!')

    # print(pessoa)
    #  -------------------------------------------------------------------------

    if continua:
        # Adição de itens em uma lista para enviar ao servidor
        itens = []

        while True: # Solicitação de dados ao usuário
            descricao = input("Digite a descrição: ")
            qtd = int(input("Digite a quantidade: "))
            preco = float(input("Digite o preço: "))
            
            item = {
                "id": str(gerador.gerarUUID()),
                "descricao": descricao,
                "qtd": qtd,
                "preco": preco
            }
            if qtd and preco > 0:
                itens.append(item)
            
            continuar = input("1 - Continuar\n2 - Parar\nDigite sua escolha: ")
            
            if continuar == '2':
                break

        # Requisição para a API de negócio para adicionar item.
        # Função retorna a Pessoa com os itens na lista
        pessoa = asyncio.run(servico.addItem(pessoa,itens))

        if pessoa.get('Erro'):
            print(f'\nERRO: {pessoa["Erro"]}')
            continua = False
        else:
            print('\nItem(s) adicionado(s) com sucesso!')
            continua = True

        # print(pessoa)

    # ------------------------------------------------------------------
        
    # Requisição de cálculos para a API de negócios - soma total e quantidade total de itens na lista
    # Retorna a pessoa os atributos atualizados
    if continua:
        pessoa = asyncio.run(servico.fazerCalculos(pessoa))

        def listarTudo(pessoa):
            print(f"\n ----------- LISTAGEM --------------")
            print(f"ID da Pessoa: {pessoa['id']}")
            print(f"Nome: {pessoa['nome']['nome']}")
            print("\nLista de Compras:")
            print(f"ID da Lista: {pessoa['lista']['id']}")
            print(f"Data de Criação: {pessoa['lista']['dataCriacao']}")
            print(f"Valor Total: {pessoa['lista']['valorTotal']}")
            print(f"Quantidade Total de Itens: {pessoa['lista']['qtdTotalItens']}")
            print("\nItens:")
            print(f"- Descrição -> Quantidade -> Preço")
            for item in pessoa['lista']['listaItens']:
                print(f"- {item['descricao']} -> {item['qtd']} -> {item['preco']} R$")

            print(f" ----------- [FIM LISTAGEM] --------------")

        listarTudo(pessoa)

        # Passa como parâmetro a versão final da Pessoa e grava os dados no JSON
        pessoa = asyncio.run(servico.grava(pessoa))
        
        if pessoa.get('Erro'):
            print(f'\nERRO: {pessoa["Erro"]}')
            continua = False
        else:
            print(f'\n-> {pessoa["Sucesso"]}')
            continua = True

    else:
        print("\nProcesso encerrado por falhas")
