from fastapi import FastAPI
from fastapi import FastAPI
from typing import List, Tuple

import httpx

escalonadorAPI = FastAPI()

# Lista de tuplas contendo IP e porta dos serviços de negócios disponíveis
negocios_disponiveis: List[Tuple[str, int]] = [
    # ("172.25.0.3", 8002),
    # ("172.50.0.1", 8005),
    ("localhost", 8010)
]

# Lista de tuplas contendo IP e porta dos serviços de dados disponíveis
dados_disponiveis: List[Tuple[str, int]] = [
    ("172.10.0.2", 8005),
    ("172.10.0.1", 8010),
    ("localhost", 8011)
]

# Lista de tuplas contendo IP e porta dos banco de dados disponíveis
bancos_disponiveis: List[Tuple[str, int]] = [
    ("172.45.0.11", 27017),
    ("172.19.0.9", 27017),
     ("172.19.0.10", 27017)
]

@escalonadorAPI.get("/") # Link
def home(): # Função que vai rodar.
     return "Eu sou o escalonador!.."


# Seleção do serviço de negócio
@escalonadorAPI.get("/seleciona_negocio/")
async def seleciona_negocio():
    global negocios_disponiveis

    if not negocios_disponiveis:
        return {"message": "Não há serviços disponíveis."}
    
    temp_negocios = negocios_disponiveis[:]
    resultado_final = {"message": "Não há um negócio disponível."}  # Resposta padrão para caso de falha em todas as tentativas
    
    for negocio in temp_negocios:
        ip, porta = negocio
        print('Testando conexão ', ip, '->', porta)
        
        conexao_bem_sucedida = await testar_conexao(ip, porta)
        
        print('conexao_bem_sucedida >> ', conexao_bem_sucedida)
        if conexao_bem_sucedida:
            # print('  -->> OK > ip:', ip, 'porta:', porta)
            resultado_final = {"ip": ip, "porta": porta}  # Atualiza a resposta com o serviço disponível
            break  # Sai do loop após encontrar um serviço disponível
    

    print('RETURN: ', resultado_final)
    # Retorna IP e porta
    return resultado_final

# Seleção do serviço de dados
@escalonadorAPI.get("/seleciona_dados/")
async def seleciona_dados():
    global dados_disponiveis

    if not dados_disponiveis:
        return {"message": "Não há serviços disponíveis."}
    
    temp_dados = dados_disponiveis[:]
    resultado_final = {"message": "Não há um negócio disponível."}  # Resposta padrão para caso de falha em todas as tentativas
    
    for dado in temp_dados:
        ip, porta = dado
        print('Testando conexão ', ip, '->', porta)
        
        conexao_bem_sucedida = await testar_conexao(ip, porta)
        
        print('conexao_bem_sucedida >> ', conexao_bem_sucedida)
        if conexao_bem_sucedida:
            # print('  -->> OK > ip:', ip, 'porta:', porta)
            resultado_final = {"ip": ip, "porta": porta} 
            break  
    

    print('RETURN: ', resultado_final)
    # Retorna IP e porta
    return resultado_final

# Seleção do banco de dados
@escalonadorAPI.get("/seleciona_banco/")
async def seleciona_banco():
    global bancos_disponiveis

    if not bancos_disponiveis:
        return {"message": "Banco de dados não está disponível."}
    
    temp_banco = bancos_disponiveis[:]
    resultado_final = {"message": "Não há um banco de dados disponível."} 
    
    for dado in temp_banco:
        ip, porta = dado
        print('Testando conexão ', ip, '->', porta)
        
        conexao_bem_sucedida = await testar_conexao(ip, porta)
        
        print('conexao_bem_sucedida >> ', conexao_bem_sucedida)
        if conexao_bem_sucedida:
            resultado_final = {"ip": ip, "porta": porta}  
            break  

    # Retorna IP e porta
    return resultado_final 

# Teste de conexãpo com serviços/banco de dados
async def testar_conexao(ip: str, porta: int) -> bool:
    """
    Testa a conexão com o serviço especificado pelo IP e porta.
    Retorna True se a conexão for bem-sucedida, False caso contrário.
    """
    url = f"http://{ip}:{porta}"
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(url, timeout=10)
            response.raise_for_status()
            return True
    except httpx.HTTPError:
        return False