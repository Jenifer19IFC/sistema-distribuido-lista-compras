import uuid

class GeradorUUID:
    
    # Gera id para os Objetos
    @staticmethod
    def gerarUUID():
        id = str(uuid.uuid4())
        return id
