import asyncio
from http.client import HTTPException
from typing import List
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from Calculo import Calculo
from Models import Item, ItemDetails, PessoaInput, PessoaModel
from dados.MovimentacaoDados import MovimentacaoDados
from RequisicoesNegocio import RequisicoesNegocio

negocioAPI = FastAPI() # Instância da API de negócios

@negocioAPI.get("/") # Link
def home(): # Função que vai rodar
     return "Trabalhando com negócio..."

# Realiza cálculos de valor total e quantidade total de itens
@negocioAPI.post("/calculos/") # Link
def calculos(pessoa: PessoaModel): # Função que vai rodar
     somaTotal, qtdTotal = Calculo.calcular_totais(pessoa.lista.listaItens)

     # Atribuição dos cálculos à pessoa
     pessoa.lista.valorTotal = somaTotal
     pessoa.lista.qtdTotalItens = qtdTotal

     return pessoa

# Criação da pessoa e retorno da mesma
@negocioAPI.post("/criaPessoa/") 
async def criaPessoa(nome: str):
    if len(nome) <= 3:
        return {'Erro':'O nome deve ter mais de 3 letras.'}
    else:
        servico = RequisicoesNegocio(None)
        # Solicita ao escalonador o serviço de dados disponível
        url_dados = await obter_url_servico(servico)
        servico = RequisicoesNegocio(url_dados)
        pessoa = await servico.post_pessoa(nome)
        return pessoa

# Adição de itens no objeto Pessoa
@negocioAPI.post("/addItem/")
async def addItem(pessoa: PessoaModel, itens: List[ItemDetails]):
    if not itens:
        raise HTTPException(status_code=400, detail="A lista deve ter pelo menos um item.")
    else:
        servico = RequisicoesNegocio(None)
        # Solicita ao escalonador o serviço de dados disponível
        url_servico = await obter_url_servico(servico)
        servico = RequisicoesNegocio(url_servico)
        pessoa = await servico.post_item(pessoa, itens)
        return pessoa

#Gravação dos dados
@negocioAPI.post("/grava/")
async def grava(pessoa: PessoaModel): 
    if pessoa is None:
        return {"Erro": "Não foi possível gravar um dado nulo: pessoa"}
    else:
        servico = RequisicoesNegocio(None)
        # Solicita ao escalonador o serviço de dados disponível
        url_servico = await obter_url_servico(servico)  
        servico = RequisicoesNegocio(url_servico)
        pessoa = await servico.grava_pessoa(pessoa)
        return {"Sucesso": "Dados gravados com sucesso!", "Dados Gravados": pessoa}

# Requisição para o ESCALONADOR para obter um serviço de dados disponível
async def obter_url_servico(servico: RequisicoesNegocio) -> str:
    print('\nVerificando conexão com o servidor de dados...')
    try:
        dados = await servico.seleciona_dados()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # print('Dados --> ', dados)

    # Verifica se a resposta contém as chaves 'ip' e 'porta', indicando uma conexão bem-sucedida
    if isinstance(dados, dict) and 'ip' in dados and 'porta' in dados:
        url_dados = f"http://{dados['ip']}:{dados['porta']}"
        print('Conectado ao servidor ', url_dados)
        return url_dados
    else:
        raise HTTPException(status_code=500, detail="Não foi possível obter um serviço/negócio disponível.")