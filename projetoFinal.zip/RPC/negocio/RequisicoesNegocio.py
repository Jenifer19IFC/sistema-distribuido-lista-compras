import asyncio
from http.client import HTTPException
from typing import List
from fastapi import FastAPI
from fastapi.responses import JSONResponse
import httpx
from Calculo import Calculo
from Models import Item, ItemDetails, PessoaInput, PessoaModel
from dados.MovimentacaoDados import MovimentacaoDados

class RequisicoesNegocio:

    # def __init__(self):
    #     self.base_url = "http://localhost:8011"

    def __init__(self, url_dados):
        self.url_dados = url_dados

    async def seleciona_dados(self):  # Requisição para o ESCALONADOR
        url_escalonador = "http://localhost:8012/seleciona_dados/"
        async with httpx.AsyncClient(timeout=120) as client:  
            response = await client.get(url_escalonador)
            return response.json()

    # Requisição para o serviço de dados ajustar objeto Pessoa
    async def post_pessoa(self, nome: str): 
        url = f"{self.url_dados}/postPessoa/"
        data = {"nome": nome}
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=data, timeout=120)
            return response.json()

    # Requisição para o serviço de dados ajustar objeto Pessoa - add itens
    async def post_item(self, pessoa: PessoaModel, itens: List[ItemDetails]): 
        url = f"{self.url_dados}/postItem/"
        payload = {
            "pessoa": {
                "id": pessoa.id,  
                "nome": {"nome": pessoa.nome['nome']},  
                "lista": {  
                    "id": pessoa.lista.id, 
                    "listaItens": [],
                    "dataCriacao": pessoa.lista.dataCriacao,
                    "valorTotal": pessoa.lista.valorTotal,
                    "qtdTotalItens": pessoa.lista.qtdTotalItens
                }
            },
            "itens": [item.dict() for item in itens]  
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload)
            if response.status_code == 200 and response.text:
                return response.json()
            else:
                return {"Erro": "O servidor respondeu com uma resposta vazia ou inválida."}

    # Requisição para o serviço de dados gravar
    async def grava_pessoa(self, pessoa: PessoaModel): 
        url = f"{self.url_dados}/gravaPessoa/"
        payload = {
            "id": pessoa.id,  
            "nome": {"nome": pessoa.nome['nome']},  
            "lista": {
                "id": pessoa.lista.id,  
                "listaItens": [item.dict() for item in pessoa.lista.listaItens],
                "dataCriacao": pessoa.lista.dataCriacao,
                "valorTotal": pessoa.lista.valorTotal,
                "qtdTotalItens": pessoa.lista.qtdTotalItens
            }
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, timeout=120)
            return response.json()
