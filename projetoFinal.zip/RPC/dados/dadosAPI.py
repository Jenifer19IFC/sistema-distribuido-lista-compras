from http.client import HTTPException
import json
from typing import List
from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from MovimentacaoDados import MovimentacaoDados
from Models import PessoaInput
from Models import ItemDetails
from Models import PessoaModel
from RequisicoesDados import RequisicoesDados

dadosAPI = FastAPI() # Instância da API de dados

@dadosAPI.get("/") # Link
def home(): # Função que vai rodar
     return "Trabalhando com dados.."

# Cria a Pessoa e já vincula a uma lista vazia
@dadosAPI.post("/postPessoa/") 
def addPessoa(nome: PessoaInput):
     pessoa = MovimentacaoDados.addPessoa(nome)
     lista = MovimentacaoDados.criaLista()
     pessoa.setLista(lista)
     return pessoa

# Adiciona itens na lista e vincula a Pessoa
@dadosAPI.post("/postItem/")
async def addItem(pessoa: PessoaModel, itens: List[ItemDetails]):
    for item_details in itens:
        item = MovimentacaoDados.addItem(item_details.descricao, item_details.qtd, item_details.preco)
        pessoa.lista.listaItens.append(item)
    return pessoa

# # Gravação de dados no formato JSON
# @dadosAPI.post("/gravaPessoa/") # Link
# def gravaPessoa(pessoa: PessoaModel): # Função que vai rodar
#      MovimentacaoDados.gravar(pessoa)
#      return pessoa

# Gravação de dados no MongoDB
@dadosAPI.post("/gravaPessoa/") # Link
async def gravaPessoa(pessoa: PessoaModel): # Função que vai rodar

    servico = RequisicoesDados(None)
    url_banco = await obter_url_banco(servico)
    # servico = RequisicoesDados(url_banco)
    print('RECEBI PARA GRAVAR: ', pessoa)
    movimentacao_dados = MovimentacaoDados(url_banco) 
    movimentacao_dados.gravar_pessoa(pessoa) 
    return pessoa

# Obtém banco de dados 
async def obter_url_banco(servico: RequisicoesDados) -> str:
    print('\nVerificando conexão com o banco de dados...')
    try:
        banco = await servico.seleciona_banco() # Requisição para o escalonador
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # Verifica se a resposta contém as chaves 'ip' e 'porta', indicando uma conexão bem-sucedida
    if isinstance(banco, dict) and 'ip' in banco and 'porta' in banco:
        url_banco = f"mongodb://{banco['ip']}:{banco['porta']}"
        print('Conectado ao banco ', url_banco)
        return url_banco
    else:
        raise HTTPException(status_code=500, detail="Não foi possível obter um serviço/negócio disponível.")