from pymongo import MongoClient

# Seleção de database + coleção e inserção no banco

class MongoConexao:

    def __init__(self, string_conexao):
        self.client = MongoClient(string_conexao)
        self.db = self.client.dbnovo # Banco de dados
        self.colecao_pessoa = self.db.colecao# Coleção

    def inserir_pessoa(self, pessoa):
        self.colecao_pessoa.insert_one(pessoa)
    