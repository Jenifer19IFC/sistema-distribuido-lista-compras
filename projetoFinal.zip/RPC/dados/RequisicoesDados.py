import asyncio
from http.client import HTTPException
from typing import List
from fastapi import FastAPI
from fastapi.responses import JSONResponse
import httpx
from Models import Item, ItemDetails, PessoaInput, PessoaModel
from dados.MovimentacaoDados import MovimentacaoDados

class RequisicoesDados:

    def __init__(self, url_dados):
        self.url_dados = url_dados

    # Solicita bando de dados disponível ao escalonador
    async def seleciona_banco(self):  
        url_escalonador = "http://localhost:8012/seleciona_banco/"
        async with httpx.AsyncClient() as client:
            response = await client.get(url_escalonador,  timeout=120)
            return response.json()